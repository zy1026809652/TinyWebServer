#include "webserver.h"

WebServer::WebServer(int port, int timeoutMs) : port_(port), timeoutMs_(timeoutMs), 
                    epoller_(new Epoller()) {
    InitSocket_();
}

bool WebServer::InitSocket_() {
    // 创建socket
    listenFd_= socket(AF_INET, SOCK_STREAM, 0);
    if (listenFd_ == -1) {
        perror("socket");
        return -1;
    }

    // 设置端口复用
    int optval = 1;
    setsockopt(listenFd_, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval));

    struct sockaddr_in saddr;
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(port_);
    // 绑定
    int ret = bind(listenFd_, (struct sockaddr*)&saddr, sizeof(saddr));
    if (ret == -1) {
        perror("bind");
        return -1;
    }

    // 监听
    ret == listen(listenFd_, 128);
    if (ret == -1) {
        perror("listen");
        return -1;
    }

    // 将listenFd_注册至epoll事件表中
    epoller_->AddFd(listenFd_, EPOLLIN);

    while (1) {
        int num = epoller_->Wait(timeoutMs_);
        if (num == -1) {
            perror("epoll_wait");
            exit(-1);
        }
        printf("num = %d\n", num);
        for (int i = 0; i < num; ++i) {
            int curfd = epoller_->GetEventFd(i);
            if (curfd == listenFd_) {  // 有客户端连接进来
                struct sockaddr_in cliaddr;
                socklen_t len = sizeof(cliaddr);
                int cfd = accept(listenFd_, (struct sockaddr*)&cliaddr, &len);

                // 获取客户端信息
                char cliIp[16];
                inet_ntop(AF_INET, &cliaddr.sin_addr.s_addr, cliIp, sizeof(cliIp));
                unsigned short cliPort = ntohs(cliaddr.sin_port);
                // 输出客户端的信息
                printf("client's ip is %s, and port is %d\n", cliIp, cliPort );

                int flag = fcntl(cfd, F_GETFL);
                flag |= O_NONBLOCK;  // 设置文件描述符非阻塞
                fcntl(cfd, F_SETFL, flag);

                epoller_->AddFd(cfd, EPOLLIN | EPOLLET);  // cfd注册至内核事件表中，并设置ET模式
            } else {  // 有客户端发送数据
                if (epoller_->GetEvents(i) & EPOLLOUT) {
                    continue;
                }
                char buf[5];
                int len = 0;
                while ((len = read(curfd, buf, sizeof(buf))) > 0) {
                    write(STDOUT_FILENO, buf, len);
                    write(curfd, buf, len);
                }
                if (len == 0) {
                    printf("client close...\n");
                } else if (len == -1) {
                    if (errno == EAGAIN) {
                        printf("read over ...\n");
                    } else {
                        perror("read\n");
                        exit(-1);
                    }
                }
            }
        }
    }
    close(listenFd_);
    return 0;
}